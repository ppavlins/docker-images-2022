# Python Textovka

Introduction to python by creating the text based adventure game (interactive fiction).

There are two versions of the game:

1. procedural implementation - run file `game.py`
2. object oriented implementation - run file `oop-game.py`

**Comment:** OOP version is not finished. It is just the basics. Feel free to finish it at home by yourself ;)


